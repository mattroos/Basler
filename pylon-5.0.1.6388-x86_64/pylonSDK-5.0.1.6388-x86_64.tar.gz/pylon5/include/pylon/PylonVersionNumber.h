// This file is generated automatically during PYLON build process
// DO NOT EDIT

#define PYLON_VERSION_MAJOR          5
#define PYLON_VERSION_MINOR          0
#define PYLON_VERSION_SUBMINOR       1
#define PYLON_VERSION_BUILD          6388
#define PYLON_VERSIONSTRING_MAJOR    "5"
#define PYLON_VERSIONSTRING_MINOR    "0"
#define PYLON_VERSIONSTRING_SUBMINOR "1"
#define PYLON_VERSIONSTRING_BUILD    "6388"
#define PYLON_VERSIONSTRING_SUFFIX   ""

#define PYLON_VERSIONSTRING_COMMENT  "${build.timestamp}; ${env.COMPUTERNAME}"
